
import React from 'react';

const LandPage = () => {
  return (
    <div className="h-screen flex items-center justify-center text-cyan-300 bg-gray-950 font-mono">
      <h1 className="text-4xl font-bold">Land di Gioco – in costruzione</h1>
    </div>
  );
};

export default LandPage;
